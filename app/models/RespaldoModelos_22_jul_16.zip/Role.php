<?php


use Zizaco\Entrust\EntrustRole;

/**
 *
 */
class Role extends EntrustRole
{
	protected $table="roles";

}



