<?php

/**
 *
 */
class skin extends Eloquent
{
  protected $table = 'skins';
}


