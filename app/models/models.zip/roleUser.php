<?php


class assignedRole extends Eloquent
{
	protected $table="assigned_role";

}

