<?php
class recordatorioHijo extends Eloquent{
 protected $table='recordatorios_hijos';
 public $timestamps =false;
}
