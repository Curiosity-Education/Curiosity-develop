@extends('admin_base')

@section('title')
  Temas
@stop

@section('mi_css')
  {{HTML::style('/packages/css/curiosity/tema.css')}}
@stop

@section('titulo_contenido')
  Temas
@stop

@section('migas')
  <li><a href="/nivel">Grados Escolares</a></li>
  <li class="fa fa-angle-right separatorBrand"></li>
  <li><a href="/inteligencia{{$objetos[0]['nivel_id']}}">{{$objetos[0]['nivel_nombre']}}</a></li>
  <li class="fa fa-angle-right separatorBrand"></li>
  <li><a href="/bloque{{$objetos[0]['inteligencia_id']}}">{{$objetos[0]['inteligencia_nombre']}}</a></li>
  <li class="fa fa-angle-right separatorBrand"></li>
  <li><a href="/tema{{$objetos[0]['bloque_id']}}">{{$objetos[0]['bloque_nombre']}}</a></li>
@stop

@section('panel_opcion')
  @foreach($objetos as $objeto)
  <div class='col-md-4 objeto'>
    <div class='box box-widget widget-title objetoPointer' data-rol='{{$rol}}'' data-prem='{{ $objeto->isPremium }}' data-estatus={{$objeto->estatus}} data-id = {{ $objeto->id }}>
      @if(Auth::user()->hasRole('hijo_free') || Auth::user()->hasRole('root') && $objeto->isPremium == 1 )
      <!-- <img src="/packages/images/premium.png" class="img-responsive isPremium"/> -->
      <span class="fa fa-lock isPremium" style="background-color: {{$objeto->bg_color}}"></span>
      @endif
      <div class="widget-title-header" style="background-color: {{$objeto->bg_color}}">
        <h3 class='widget-title-set text-center'> {{$objeto->nombre}} </h3>
        <h5 class='widget-title-desc'></h5>
      </div>
      @if($objeto->estatus == "lock")
      <div class="butonEstatus text-center" style="background-color: {{$objeto->bg_color}}">
        <span class='fa fa-clock-o fa-estatus-color'></span>&nbsp;
        Próximamente
      </div>
      @endif
      <div class='widget-title-image'>
        <img class='img-circle' src='/packages/images/temas/{{$objeto->imagen}}'>
      </div>
      <div class='box-footer'>
        <div class='row'>
          <div class='col-xs-4 border-right'>
            <div class='description-block'>
            </div>
          </div>
          <div class='col-xs-4 border-right'>
            @if($objeto->estatus != "lock")
              <div class='description-block'>
                <span class='fa fa-star fa-star-color fa-4x tooltipShow' title='{{$objeto->descripcion}}'></span>
              </div>
            @endif
          </div>
          <div class='col-xs-4'>
            <div class='description-block btnIn'>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  @endforeach

  <div class="modal fade" id="modalPremium" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true" data-keyboard="false">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body text-center">
          <button type="button" class="close" data-dismiss="modal" id="closePrem" aria-hidden="true">&times;</button>
          <span class="fa fa-star" id="iconPrem"></span>
          <br><br>
          <h4 class="tituloPrem">Desbloquea el Tema.</h4>
          <br>
          <p class="text-center bodyPrem">
            Este Tema se encuentra bloqueado por hoy.<br>
            Puedes Jugar en él pasándote a Premium ahora.<br><br>
            Cuentale ahora a tus padres, No esperes más!!
          </p>
          <!-- <br>
          <button type="button" id="botonPremium" class="btn btn-primary btn-lg">
            Notificarle a mis Padres
          </button> -->
        </div>
      </div>
    </div>
  </div>

@stop

@section('mi_js')
  {{HTML::script('/packages/js/curiosity/tema.js')}}
@stop
