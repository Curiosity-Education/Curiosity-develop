$(document).ready(function() {


  $(".box-curso").click(function(event) {
    alert($(this).attr('id'));
  });


});
