$(document).ready(function(){

  $('.temario').click(function(){
    window.location.href = "/bloques";
  })

});
