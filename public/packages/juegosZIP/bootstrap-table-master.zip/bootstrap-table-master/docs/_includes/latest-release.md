### Latest release (2016-2-17)

#### v1.10.1

- revert: feat: update escape to false
- feat: add `checkInvert` method
- feat: add `bootstrap-table-he-IL.js`
- bug: update grunt to development dependency
- bug: press on toolbar elements, the key-events it will not run
- bug: remove bogus conditions that will always be true
- bug: refactor filter control select input initialization
- bug: typo in Slovak translation

