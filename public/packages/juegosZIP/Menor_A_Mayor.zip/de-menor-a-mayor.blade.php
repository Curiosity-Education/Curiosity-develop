@extends('juegos.vista_juego_layer')

@section('juego_css')
  {{HTML::style('/packages/css/curiosity/juegos/de-menor-a-mayor.css')}}
@stop

@section('title')
  Menor-Mayor
@stop

@section('juego')
@stop

@section('game')
@stop

@section('juego_js')
  {{HTML::script('packages/js/curiosity/juegos/de-menor-a-mayor.js')}}
 
@stop
